#include<stdio.h>

int main()
{
	int no, temp=0;
	printf("Enter no");
	scanf("%d",&no);
	for(int i=2;i<(no/2);i++)
	{
		if(no%i==0)
		{
			temp=1;
		}

	}
	if(temp==1)
	{
		printf("No is not a Prime no");
	
	}
	else
		printf("No is prime no");


}
