#include<stdio.h>
int main()

{
	int marks;
 printf("enter the marks out of 500");
 scanf("%d",&marks);
 if(marks<=100)
 {	 printf("your grade is 'D'");
 }
 else if(marks<=200)
	          printf("your grade is 'c'");
 else if(marks<=300)
                  printf("your grade is 'B'");
 else if(marks<=400)
                  printf("your grade is 'A'");
 else if(marks<=500)
                  printf("your grade is 'A+'");






}
