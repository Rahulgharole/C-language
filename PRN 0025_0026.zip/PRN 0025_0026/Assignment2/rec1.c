#include<stdio.h>
int rec (int);
int main()
{
        int num,a,b,res,res1;
        printf("Enter no");
        scanf("%d",&num);
       res=rec(num);
       while(res>=9)
       {
	res=rec(res);
       }

printf("rec sum=%d",res);




}

int rec(int num)
{
	int a,b=0;
                while(num!=0)
                {
                        a=num%10;
                        b=b+a;
                        num=num/10;
                }
		return b;
}      

