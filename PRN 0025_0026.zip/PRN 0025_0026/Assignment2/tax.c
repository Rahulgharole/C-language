#include<stdio.h>

void tax(float ,int);
int main()

{
	char gen; int age; float inc ,tax_per;
	printf("enter M for male\n enter F for female");
	scanf("%c",&gen);
	printf("enter age");
	scanf("%d",&age);
	printf("enter income in lakh");
	scanf("%f",&inc);
	if(gen=='M')
	{
		if(age> 60)
		{
			if (inc>2.5 && inc<10)
			{
				printf("your tax percentage=5%%");
				tax(inc,5);
			}		
			else
			{
				printf(" your tax percentage=10%%");
				tax(inc,10);
			}
		}
		else
		{
			 if (inc>2.5 && inc<10)
	
			{
				printf("your tax percentage=10%%");
				tax(inc,10);
			}		
			else
			{
				printf(" your tax percentage is 15%%");
				tax(inc,15);
			}
		}
	}

	else
        {
                if(age> 60)
                {
                         if (inc>2.5 && inc<10)

                        {
                                printf("your tax percentage is 3%%");
                                tax(inc,3);
                        }
                        else
                        {
                                printf(" your tax percentage is 8%%");
                                tax(inc,8);
                        }
                }
                else
                {
			 if (inc>2.5 && inc<10)
	                        
			{
                                printf("your tax percentage is 8%%");
                                tax(inc,8);
                        }
                        else
                        {
                                printf(" your tax percentage is 12%%");
                                tax(inc,12);
                        }
                }
        }







}


void tax(float a , int b)
{
				double tax_per;
				tax_per=(a*b*100000)/100;
				printf("\nyour tax is=%f\n",tax_per);

}
