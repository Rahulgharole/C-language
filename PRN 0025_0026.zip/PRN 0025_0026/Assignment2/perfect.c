#include<stdio.h>

int main()
{
	int num,div,res=0;
	printf("enter no");
	scanf("%d",&num);
	for(int i=1;i<=num;i++)
	{
		div=num%i;
		if(div==0)
		{
			res=i+res;
		}
	
	}
	if((res/2)==num)
		printf("%d is perfect no",num);
	else
		printf("%d is not a perfect no",num);
}
