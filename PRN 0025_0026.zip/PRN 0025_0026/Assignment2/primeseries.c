#include<stdio.h>

int main()
{
	int no, temp;
	printf("Enter limit");
	scanf("%d",&no);
	for(int j=2;j<=no;j++)
{
	temp=0;
	for(int i=2;i<j;i++)
	{
		if(j%i==0)
		{
			temp=1;
		}

	}
	if(temp==0)
	{
		printf("%d  ",j);
		
	}
	

}
				



}
