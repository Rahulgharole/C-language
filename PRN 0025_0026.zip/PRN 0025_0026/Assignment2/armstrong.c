#include<stdio.h>
int main()

{
	int no,rem,res,num,result=0;
	printf("Enter no");
	scanf("%d",&no);
	num=no;
	while(no!=0)
	{

	rem=no%10;
	res=rem*rem*rem;
	result=result+res;
	no=no/10;
	
	}
	if(result==num)
	{
		printf("no=%d Armstrong no",num);
	}
	else
		printf("no=%d is not armstrong no",num);
}

