#include<stdio.h>
int add(int,int);
int sub(int,int);
int mul(int,int);
int div(int,int);
int res;
int main()
{
	int a,b,ch,result;
	printf("Enter two values");
	scanf("%d %d",&a, &b);
	printf("enter 1 for addition\n enter 2 for sub\n enter 3 for mul \n  enter 4 for division");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
			result=add(a,b);
			printf("addition=%d",result);
			break;

		case 2: result=sub(a,b);
			printf("substraction=%d",result);
			break;

		case 3: result=mul(a,b);
			 printf("mul=%d",result);
                        break;

		case 4: result=div(a,b);
			printf("division=%d",result);
			break;

		default: printf("wrong choice");

	}
}

int add(int x,int y)
{
 res=x+y;
 return res;

}

int sub(int x,int y)
{
 res=x-y;
 return res;

}

int mul(int x,int y)
{
 res=x*y;
 return res;

}

int div(int x,int y)
{
 res=x/y;
 return res;

}
