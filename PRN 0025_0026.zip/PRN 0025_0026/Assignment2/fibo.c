#include<stdio.h>

int main()
{
	int a=0, b=1,c;
	int ch;
	printf("Enter series limit");
	scanf("%d",&ch);
	for(int i=0;i<10;i++)
	{
		printf("%d ",a);
		c=b;
		b=a+b;
		a=c;
	}
}
