#include<stdio.h>
struct B
{
	char ch;
	int x;
};
struct A
{
	int a;
	float b;
	char c;
	struct B b1; 
};

int main()
{
	struct A a1;

	printf("Enter the details");

	scanf("%d %f %c %x %c",&a1.a,&a1.b,&a1.c,&a1.b1.x,&a1.b1.ch);

	printf("%d %f %c %x %c\n",a1.a,a1.b,a1.c,a1.b1.x,a1.b1.ch);

}



