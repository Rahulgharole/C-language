#include<stdio.h>
#include<stddef.h>
union A
{
	int x;
	int y;
	char ch;

};

int main()
{

union A a1;
a1.x=0x10;
a1.y=0x1121;


printf("%x %c\n",a1.y,a1.ch);

printf("%u\n",sizeof(union A));

printf("%d\n",offsetof(union A,x));

printf("%d\n",offsetof(union A,y));

printf("%d\n",offsetof(union A,ch));


}
