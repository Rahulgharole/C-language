#include<stdio.h>
#include<stdio_ext.h>

struct student{

	int r;
	char name[10];
	char sub[5][10];
	int  submarks[5];



};


int main(){

	struct student stud[3];
	
	for(int i=0;i<3;i++){
		printf("Enter %dst student name\n",i+1);
			__fpurge(stdin);
		scanf("%s",stud[i].name);
		
		printf("Enter %dst student roll no\n",i+1);
			__fpurge(stdin);
		scanf("%d",&stud[i].r);

		for(int j=0;j<5;j++){
			printf("Enter %d  sub marks\n",j+1);
			__fpurge(stdin);
			scanf("%d",&stud[i].submarks[j]);
		}
	}

	for(int i=0;i<3;i++)
	{
		printf("%d student data is\n",i+1);
		printf("roll no-> %d \tname->%s \t ",stud[i].r,stud[i].name);
		for(int j=0;j<5;j++)
		{
			printf(" %d subject marks->%d\n",j,stud[i].submarks[j]);

		}

	}

		


}



