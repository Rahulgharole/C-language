#include<stdio.h>
#include<stddef.h>
int main()
{
	char *p;
	int q;

	struct x
	{
		int a;
		double y;
		float z;
		char ch;
	}a1;
	//printf("address of ch is %p\n",&a1.ch);

	printf("offset x %d\n", offsetof(struct x,a));
	printf("offset y %d\n",offsetof(struct x,y));
	printf("offset z %d\n",offsetof(struct x,z));
	printf("offset ch %d\n",offsetof(struct x,ch));

	q=offsetof(struct x,z);
	p=((char*)&a1.z)-q;

	printf("address of z is %p\n",&a1.z);

		printf("base adress is %p",p);

}

