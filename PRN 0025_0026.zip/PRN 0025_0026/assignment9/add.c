#include<stdio.h>
#include<stddef.h>

typedef struct structure{

	int a;
	char c;
	float f;


}s1;

int main(){

	s1 s;
	printf("offset(a)=%ld\noffset(c)=%ld\noffset(f)=%ld\n",offsetof(s1,a),offsetof(s1,c),offsetof(s1,f));
	
	float *p=&s.f;

	long int y=(long int)p;

	printf("address of int s=%ld\n",&s);

	
	
	printf("address of s1=%ld\n",(y-(offsetof(s1,f))));



}


