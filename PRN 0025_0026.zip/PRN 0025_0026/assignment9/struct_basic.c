#include<stdio.h>

struct stud{

	char n[10];
	int rollNo;
	float m;

};

int main(){

/*	struct stud s;
	printf("Enter name\n enter rollNo\nenter marks\n");
	scanf("%s %d %f",s.n,&s.rollNo,&s.m);
*/	
//	printf("%s %d %f",s.n,s.rollNo,s.m);

	struct stud s={"aaaa",7,12};

	printf("%s %d %f",s.n,s.rollNo,s.m);


}



