#include<stdio.h>
#include<stdio_ext.h>

struct emp
{
	int empid;
	char name[20];
	float salary;
	int year;
};
char* service(struct emp *);
int main()
{

	struct emp E[5];
	int sum=0,i,avg,min,max;
	char* se;
	for(i=0;i<5;i++)
	{
		printf("Enter the details of employee%d\n employee id: ",i+1);

		scanf("%d",&E[i].empid);

		printf("\n Name:");
		scanf("%s",E[i].name);
		__fpurge(stdin);

		printf("\n salary :");
		scanf("%f",&E[i].salary);
		printf("\n year");
		scanf("%d",&E[i].year);
	}

		max=E[0].salary;
		min=E[0].salary;
	for(i=0;i<5;i++)
	{	
		if(E[i].salary>max)
			max=E[i].salary;
		if(E[i].salary<min)
			min=E[i].salary;
		sum=sum+E[i].salary;
	}



	

	

	

	avg=sum/5;
	se=service(E);

	printf(" Minimum salary is %d\n",min);
	printf("Maximum salary is %d\n",max);
	printf("sum of salaries is %d\n",sum);
	printf("average salary is %d\n",avg);

	printf("max service given by  employee %s",se);


}

char* service(struct emp *y)
{

char* s;
int m=y->year;
	for(int i=1;i<5;i++)
	{
	    if((y+i)->year <m)
	     s=(y+i)->name;
	}

	return s;
}

	
