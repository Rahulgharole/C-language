#include<stdio.h>
union c{ 
		int x;
		double z;
		float y;
		//union d d1;
};
struct a{
		int x;
		float y;
		char ch;
		union c c1;
};

struct b {
		int p;
		float q;
		struct a a1;
};


union d{
		int p;
		short int q;
		//struct e e1;
};

struct e {
		short int s;
		char str[];

};
int main()
{ 

	struct a a2;
	struct b b1;
	//union c c1;
	//union d d1;
	//struct e e1;
	printf("Enter details in structure A a2.x, a2.y,a2.ch, a2.c1.x, a2.c1.z, a2.c1.y\n");
	
	scanf("%d%f %c%d%lf%f",&a2.x,&a2.y,&a2.ch,&a2.c1.x,&a2.c1.z,&a2.c1.y);
	
	printf("\n%d %f %c %d %lf %f\n",a2.x,a2.y,a2.ch,a2.c1.x,a2.c1.z,a2.c1.y);
			
}
