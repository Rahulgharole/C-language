#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct A
	{
          int x;
          char str[20]; // (or) char str[20];
         };
int main()
{
        struct A a1 = { 101, "abc" } , a2;
          a1.x=10;

	strcpy(a1.str,"hello"); //works?
//             a1.str="hello";
	printf("%d %s",a1.x,a1.str); //works?
//	a1.str=(char*)malloc(5);
	printf("Enter the details");
	scanf("%d%s",&a1.x,a1.str); //works?
	printf("%d %s",a1.x,a1.str); //works?
	a2 = a1; //shallow copy or deep copy?

	printf("\n%d  %s",a2.x,a2.str);

}
