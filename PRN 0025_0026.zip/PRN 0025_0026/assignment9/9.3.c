#include<stdio.h>
#include<stdio_ext.h>
struct stu {
	char name[20];
	int roll;
	int marks[5];};	

int main()
{
	struct stu s[5];
	int i,j,sum[5];
	float per;

	for(i=0;i<5;i++)
	{
	printf("Enter the details of student %d \nName:",i+1);
	//gets();
	//fgets(s[i].name);
	scanf("%s",s[i].name);
	__fpurge(stdin);
	printf("Roll No. :"); 
	scanf("%d",&s[i].roll);
	printf("Marks\n");
	sum[i]=0;
	       for(j=0;j<5;j++)
        {
		printf("Subject %d:",j+1);	       
       		 scanf("%d",&s[i].marks[j]);
		printf("\n");
	sum[i]=sum[i]+s[i].marks[j];
	}
       	printf("Total marks of student %d is %d.\n",i+1,sum[i]);
	per=sum[i]/5;
	printf("The percentage marks= %.2f %% \n",per);
	
	}
	 
	for(j=0;j<5;j++)
	{ printf("Total marks in Subject %d of students are",j+1);
	   sum[j]=0;
		
	 for(i=0;i<5;i++)
	   {
		   sum[j]= sum[j]+s[i].marks[j];

	  }
		  printf(" %d\n",sum[j]); 
	}
}
