#include<stdio.h>

int main(){

	int a[3][3]={0,0,0,0,0,0,0,0,0};
	int temp;
	for(int i=0;i<=2;i++){
	
		for(int j=0;j<=2;j++){
		
			if(a[i][j]==0)
				temp=1;
			else 
				temp=0;
		
		
		}
	
	
	}
	if(temp==0)
		printf("Matrix is not null");
	else
		printf("Matrix is null");



}


