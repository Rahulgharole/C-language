#include<stdio.h>

int main ()
{
	 int a[]={1,2,3,4},b[]={1,2,3,4},c[4];

	 for(int i=0;i<=3;i++)
	 {	 c[i]=a[i]+b[i];
	
		printf("  %d",c[i]);
	 }

	 printf("\n");
 }
