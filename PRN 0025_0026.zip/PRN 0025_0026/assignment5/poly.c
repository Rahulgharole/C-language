#include<stdio.h>



int main(){

	int a[3]={1,2,3};
	int pow=2;
	int x=2,i,sum;
	sum=a[0];
    	for (i=1;i<=pow;i++)
    	{
        	sum=sum*x+a[i];
    	}
	printf("Polynomial sum=%d",sum);


}
