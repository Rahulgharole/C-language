#include<stdio.h>
int main()
{
	int d,d1,d2;
	int a[3]={1,2,3};
	int b[3]={2,3,4};
	printf("equ 1 is %dx+%dy=%d\n equ 2 is %dx+%dy=%d\n",a[0],a[1],a[2],b[0],b[1],b[2]);
	
	d=a[0]*b[1]-a[1]*b[0];
	d1=a[2]*b[1]-b[0]*b[2];
	d2=a[0]*b[2]-a[2]*b[0];

	printf("\nx=%d\n\ny=%d\n ",d1/d,d2/d);

}
