#include<stdio.h>
int main()

{
	int a[3][3];
	int b[3][3];
	printf("\n Null matrix=\n");

	for(int i=0;i<=2;i++)
	{
		printf("\n");
		for(int j=0;j<=2;j++)
		{
			a[i][j]=0;
			printf("%d\t",a[i][j]);

		}
		
	}

	printf("\n\n identity matrix\n");
	for(int i=0;i<=2;i++){
		a[i][i]=1;
		 printf("\n");
                for(int j=0;j<=2;j++)
                {
                        
                        printf("%d\t",a[i][j]);

                }
	}




}
