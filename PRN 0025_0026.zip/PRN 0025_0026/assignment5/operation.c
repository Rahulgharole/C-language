#include<stdio.h>

int main()
{
	int a[2][3]={1,2,3,4,5,6};
	int x;
	int b[2][3]={1,2,3,4,5,6};
	int c[2][3];
	int i,j;
	printf("enter 1 for add \n 2 for sub \n3 for mul ");
		scanf("%d",&x);
	switch(x)
	{
		case 1:  for( i=0;i<=1;i++)
			 { 
				 for( j=0;j<=2;j++){
				 	c[i][j]=a[i][j]+b[i][j];
					printf("%d ",c[i][j]);
				}	
			 }
			 break;
		case 2:  for(i=0;i<=1;i++)
                         { 
				 for(j=0;j<=2;j++){
                                	 c[i][j]=a[i][j]-b[i][j];
                               		 printf("%d ",c[i][j]);
                       		 }
			 }
			break;
		case 3 :   for( i=0;i<=1;i++)
                         {
				 for( j=0;j<=2;j++){
                                 	c[i][j]=a[i][j]*b[i][j];
                             	   	printf("%d ",c[i][j]);
                        	}
			 }
			break;
		default : printf("wrong choice");


	}
		


}
