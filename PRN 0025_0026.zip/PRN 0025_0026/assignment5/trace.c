#include<stdio.h>


int main(){
	int trace=0;
	int a[3][3]={10,20,30,40,50,60,70,80,90 };
	for(int i=0;i<=2;i++){
		
		trace=trace+a[i][i];	
		
		}
	printf("Trace=%d\n",trace);
	
	
	


}
