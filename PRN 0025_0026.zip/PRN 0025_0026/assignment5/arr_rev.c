#include<stdio.h>

int main ()

{
	int a[]={10,20,30,40,50};
	int b[5];
	 
	for(int i=4,j=0;i>=0;i--,j++)
		b[j]=a[i];
	for(int i=0;i<=4;i++)
		a[i]=b[i];

	for(int i=0;i<=4;i++)
		printf("  %d",a[i]);

}
