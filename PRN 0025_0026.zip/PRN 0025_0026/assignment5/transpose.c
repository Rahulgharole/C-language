#include<stdio.h>

int main(){

	int a[2][3]={10,20,30,40,50,60};
	int b[3][2];
	for(int i=0;i<2;i++){
		printf("\n\n");	
		for(int j=0;j<3;j++){
		
			printf("%d  ",a[i][j]);
		
		}	
	
	
	}
	
	for(int i=0;i<=2;i++){
                printf("\n\n");
                for(int j=0;j<=1;j++){

              		b[i][j]=a[j][i];
	      		printf("%d  ",b[i][j]);

                }


        }




}
