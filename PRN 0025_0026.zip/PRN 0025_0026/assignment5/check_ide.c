#include<stdio.h>

int main(){

	int a[3][3]={1,0,0,0,1,0,0,0,1};

	int flag=1,i,j;

	for(i=0;i<=2;i++){


		printf("\n");
	
		for(j=0;j<=2;j++){
		
			printf("%-2d",a[i][j]);
		
		
		}
	
	
	}




	for (i = 0; i <=2; i++) 

        {

            for (j = 0; j <=2; j++)

            {

                if (a[i][j] != 1 && a[j][i] != 0)

                {

                    flag = 0;

                    break;

                }

            }

        }

 

        if (flag == 1 )

            printf("\nIt is identity matrix \n");

 

        else

            printf("\nIt is not a identity matrix \n");

 	


}

