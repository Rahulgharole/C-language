#include<stdio.h>
int main()

{
	int b[2][2]={1,2,3,4};
	int a[3][3]={1,2,3,4,5,6,7,8,9};
	 int determinant,determinant1;

	for(int i=0;i<=1;i++)
	{
		printf("\n");
		for(int j=0;j<=1;j++)
			printf("%d\t",b[i][j]);
	}
		printf("\n\n");
		determinant= b[0][0]*b[1][1]-b[0][1]*b[1][0];
		printf("Determinant of 2x2 matrix: %d\t",determinant);

		printf("\n\n");
	   for(int i = 0;i < 3; i++){

             printf("\n");

      for(int j = 0;j < 3; j++)

           printf("%d\t", a[i][j]);

     }
 	 determinant1 = a[0][0]*((a[1][1]*a[2][2])-(a[2][1]*a[1][2]))-a[0][1]*(a[1][0]*a[2][2]-a[2][0]*a[1][2])+a[0][2]*(a[1][0]*a[2][1]-a[2][0]*a[1][1]);

	printf("\nDeterminant of 3X3 matrix: %d\n", determinant1);



   return 0;
}

