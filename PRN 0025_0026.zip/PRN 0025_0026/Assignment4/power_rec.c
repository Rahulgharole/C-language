#include<stdio.h>

int power_r(int,int,int);

int main(){

        int a,b;
        int pow;
	int z=1;
        printf("Enter the base and Exponent");
        scanf("%d %d",&a,&b);
	pow=power_r(a,b,z);

        printf("Power=%d",pow);


}

int power_r(int a, int b,int z){

      
	if(b!=0){

                z=z*a;	
		b--;
		power_r(a,b,z);

        }
	else 
		return z;
}


