#include<stdio.h>


int main()
{
	int x=0;
	int a=12345;
	while(a!=0)
	{
	 a=a/10;
	 x++;
	

	}
	printf("no of digits are  %d  ",x);



}
