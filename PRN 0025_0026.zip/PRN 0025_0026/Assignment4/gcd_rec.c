#include<stdio.h>


int hcf(int, int);

int main()

{
int num1, num2,r,nume,deno;
printf("enter two no");
scanf("%d %d",&num1,&num2);
if(num1>num2)
{
        nume=num1;
        deno=num2;
}
else
{
        nume=num2;
        deno=num1;
}

	r= hcf(nume,deno);
	printf("%d",r);
}




int hcf(int nume, int deno)
{
        
	if(deno!=0)
	{
		return hcf(deno,nume%deno );	
			
	}
	else

		return nume;
}

