#include<stdio.h>

void array(int b[])
{
	for(int i=0;i<=4;i++)
        {
                printf("%d ",b[i]);
        }
        printf("\n");
        for(int j=4;j>=0;j--)
        {
                printf("%d ",b[j]);
        }
}


int main()
{
	int a[5]={1,2,3,4,5};
	array(a);
}
