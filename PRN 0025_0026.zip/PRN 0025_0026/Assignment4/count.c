#include<stdio.h>

int main()
{
	int arr[4]={1,0,1,0};
	int a=0;
	int b=0;
	for(int i=0;i<=3;i++)
	{
		if(arr[i]==0)
			++a;


		else 
			++b;
	}
	printf("No of zeros=%d",a);
	printf("\nno of 1s=%d",b);
}
