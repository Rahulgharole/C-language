#include<stdio.h>

void string_rec(char b[],int i)
{
	
	if(i<5)
	{
	
	printf("%c ",b[i]);
	string_rec(b, ++i);
	}
}

void string_rec_rev(char b[],int j)
{


        if(j>=0)
        {
        
	printf("%c ",b[j]);
        string_rec_rev(b, --j);
        }
}


int main()
{
	int i=0;
	int j=4;
	char a[6]="rahul";
	string_rec(a,i);
	  printf("\n");

	string_rec_rev(a,j);
	return 0;
}
