#include<stdio.h>
void fibo(int,int,int);
int main()
{
	int a=0, b=1;
	int ch;
	printf("Enter series limit");
	scanf("%d",&ch);
	fibo(a,b,ch);
}

void fibo(int a, int b,int ch)
{
	
	if (ch!=0)
	{
		printf("%d ",a);
		--ch;
		fibo(b,b+a,ch);
	}
	
}
