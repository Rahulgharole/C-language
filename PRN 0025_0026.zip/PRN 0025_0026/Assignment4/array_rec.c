#include<stdio.h>

void array_rec(int b[],int i)
{
	
	if(i<5)
	{
	
	printf("%d ",b[i]);
	array_rec(b, ++i);
	}
}

void array_rec_rev(int b[],int j)
{


        if(j>=0)
        {
        
	printf("%d ",b[j]);
        array_rec_rev(b, --j);
        }
}


int main()
{
	int i=0;
	int j=4;
	int a[5]={1,2,3,4,5};
	array_rec(a,i);
	  printf("\n");

	array_rec_rev(a,j);
	return 0;
}
