#include<stdio.h>

int main(){
	
	int a,b;
	int pow=1;
	printf("Enter the base and Exponent");
	scanf("%d %d",&a,&b);

	for(int i=1;i<=b;i++){
		
		pow=pow*a;

	
	}
	
	printf("Power=%d",pow);



}
