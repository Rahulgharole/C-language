#include<stdio.h>

int facto(int);
int main()
{
	int num, res;
	printf("enter the no");
	scanf("%d",&num);
	res=facto(num);
	printf("factorial of given no is=%d",res);
	return 0;


}

int facto(int a)
{
	if(a!=0)
	{
		a=a*facto(a-1);

	return a;
	}
	return 1;
}
