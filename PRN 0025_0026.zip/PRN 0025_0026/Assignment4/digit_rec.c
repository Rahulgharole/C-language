#include<stdio.h>


int main()
{

	int a=12345;
	int b= digit(a);
	printf("no of digits in %d are =%d", a,b);
}

int digit(int a)

{
	static int x=0;
 	if(a>9)
	{
		++x;
		a=a/10;
		digit(a);

	
	}
	else
		return (x+1);


}
