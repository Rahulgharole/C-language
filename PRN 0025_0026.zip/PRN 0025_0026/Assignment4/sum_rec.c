#include<stdio.h>

int sum1(int);
int main()

{
int sum, num;
printf("enter the limit");
scanf("%d",&num);
sum=sum1(num);
printf("sum=%d\n\n",sum);
}

int sum1(int a)
{
 	
	if (a!=0)
	{	a=a+sum1(a-1);
		return a;
	}
		else
		return a;
}
