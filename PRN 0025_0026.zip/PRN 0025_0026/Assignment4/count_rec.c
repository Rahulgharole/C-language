#include<stdio.h>


int count_r(int arr[], int a, int b)
{
	
	static int i=0;
	
	if(i<=3)
	{
		if(arr[i]==0)
			++a;
		else
			++b;
		++i;
		count_r(arr,a,b);
		
	}
	else
	{		
		printf("0s=%d",a);
		printf("\n1s=%d",b);
	}
	

	
	
}

int main()

{

	int arr[4]={1,0,1,0};
	int a=0;
	int b=0,i=0;
	count_r(arr,a,b);

}
