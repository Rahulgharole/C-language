#include<stdio.h>

void string(char b[])
{
	for(int i=0;i<=4;i++)
        {
                printf("%c ",b[i]);
        }
        printf("\n");
        for(int j=4;j>=0;j--)
        {
                printf("%c ",b[j]);
        }
}


int main()
{
	char a[6]="rahul";
	string(a);
}
