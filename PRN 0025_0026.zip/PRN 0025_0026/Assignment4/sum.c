#include<stdio.h>

int main()
{

 int i,sum=0,num;
 printf("enter the limit");
 scanf("%d",&num);

 for(i=1;i<=num;i++)
 {
   sum=sum+i;
 
 
 }

 printf("the sum of %d  natural no are:%d\n", num,sum);



}
