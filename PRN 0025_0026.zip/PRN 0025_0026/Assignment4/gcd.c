#include<stdio.h>
int main()

{
int num1, num2,r,nume,deno;
printf("enter two no");
scanf("%d %d",&num1,&num2);
if(num1>num2)
{
	nume=num1;
	deno=num2;
}
else
{
	nume=num2;
	deno=num1;
}

r=nume%deno;
while(r!=0)
{
	
	nume=deno;
	deno=r;
	r=nume%deno;
}


printf("HCF=%d\n",deno);

}
