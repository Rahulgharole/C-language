#include<stdio.h>

int main()
{
	int num=123;
	while(num!=0)
	{
	int a;
	a=num%10;
	num=num/10;
	printf("%d",a);
	}





}
