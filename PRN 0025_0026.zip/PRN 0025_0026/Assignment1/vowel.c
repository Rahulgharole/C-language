#include<stdio.h>

int main()
{

char x;
printf("enter the character");
scanf ("%c",&x);
if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u')
	printf("the character is vowel");
else
	printf("char is not vowel");





}
