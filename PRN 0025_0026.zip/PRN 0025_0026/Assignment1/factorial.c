#include<stdio.h>
int fact(int);
int main()

{
int factorial;
int num=4;
factorial=fact(num);
printf("factorial=%d",factorial);

}

int fact(int a)
{
	int temp;
for(int i=1 ; i<a;i++)
{
 temp=a*(a-i);
}
return temp;
}
