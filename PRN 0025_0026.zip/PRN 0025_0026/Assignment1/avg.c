#include<stdio.h>
int main()
{
	float a,avg,sum=0;
printf("enter the number");
scanf("%f",&a);
for(int i=0;i<=a;i++)
{
sum=sum+(a-i);

}
avg=sum/a;
printf("sum=%f\n avg=%f",sum,avg);
}
