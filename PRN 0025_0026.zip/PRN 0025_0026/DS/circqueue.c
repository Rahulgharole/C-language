#include<stdio.h>
#include<stdlib.h>


#define size 5

void insert(int*arr,int data,int*f,int*r)
{
	if((*r==(size-1)&&(*f==0))||(*r==(*f-1)))
	{
		printf("queue is full\n");
		return;
	}
	if(*r==(size-1))
		*r=0;
	else
	++*r;

	arr[*r]=data;
	if(*f==-1)
		*f=*r;

}

int  delete(int* arr,int *f,int *r)
{
	if(*f==-1){
		printf("queue is empty\n");
		return 0;
	}
	int temp=arr[*f];
	arr[*f]=0;

	if(*f==*r)
		*f=*r=-1;
	else if(*f==(size-1))
		*f=0;
	else ++*f;
	return temp;

}


void display(int *arr)
{	printf("---------------queue-------------\n");
	for(int i=0;i<size;i++)
		printf("%d\t",arr[i]);

}
	


int main()

{
	int arr[size]={0,0,0,0,0}; int ch,data,front,rear,x;
	front=rear=-1;
	while(1)
	{
	printf(" enter the choice\t1->insert\t2->delete\t3->display\t4->exit\n");
	scanf("%d",&ch);
	switch(ch)
	{
	case 1: printf("enter the data\n");
		scanf("%d",&data);
		insert(arr,data,&front,&rear);
		break;
	case 2: x=delete(arr,&front,&rear);

		if(x>0)
			printf("deleted value is %d\n",x);
		break;
	case 3: display(arr);
	       break;	
	case 4: exit(0);

	
	}

	}

}
