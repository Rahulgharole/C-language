#include<stdio.h>
#include<stdlib.h>


struct node{
	int data;
	struct node* next;
	struct node* prev;
};

void insertatend(struct node **p,int val);
void display(struct node*p);
void insertAtBeg(struct node **p,int val);
void insertAtPos(struct node **p, int val,int pos);
int DelatPos(struct node**p,int pos);
int main()
{
	struct node* head=NULL;
	int choice,val,pos;
	while(1)
	{
	printf("\nenter the choice\n 1--> insertatend\t2--> display\t 3-->exit \t 4->insertatBeg\t 5->insertAtPos\t 6-->Delete at position\n ");
	scanf("%d",&choice);
	switch(choice)
	{
		case 1: printf("\nenter the data\n");
			scanf("%d",&val);
			insertatend(&head,val);
			break;
		case 2: printf("\n________________list______________\n");
			display(head);
			break;
		case 3: exit(0);

		case 4: printf("Enter the data\n");
			scanf("%d",&val);
			insertAtBeg(&head,val);
			break;
		case 5: printf("Enter the data and possition\n");
			scanf("%d%d",&val,&pos);
			insertAtPos(&head,val,pos);
			break;
		case 6: printf("enter the node position to delete\n");
			scanf("%d",&pos);
			int r=DelatPos(&head,pos);
			printf("deleted data value=%d",r);
			break;
		}
	}


}

void insertatend(struct node **p,int val)
{
	struct node* temp;
	struct node* t1;
	t1=*p;

	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	temp->prev=NULL;
	if(*p==NULL)
	{
		*p=temp;

	}
	else{
		while(t1->next!=NULL)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->prev=t1;

	}

}

void display(struct node*p)
{
	while(p!=NULL){
		printf("\t%d",p->data);
		p=p->next;
	}
}

void insertAtBeg(struct node **p, int val){

	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	temp->prev=NULL;
	if(*p!=NULL){
		temp->next=*p;
		temp->next->prev=temp;
		*p=temp;
	
	}
	else printf("wrong choice");



}

void insertAtPos(struct node **p, int val, int pos){

	if(pos==1){
		insertAtBeg(p,val);
		return;
	
	}
	struct node *temp;
	struct node *t1;
	t1=*p;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	temp->prev=NULL;
	int i=1;
	while(i++ < (pos-1)){
		t1=t1->next;
		
	
	}
	temp->next=t1->next;
	t1->next=temp;
	temp->prev;
	temp->next->prev=temp;


}

int DelatPos(struct node**p,int pos)

{
	struct node* t1;struct node* temp;
	t1=*p;
	temp=*p;
	int i=0;
	while(i<(pos-1))
	{
		t1=temp;
		temp=temp->next;
		++i;
		
	}
	
	int ret=temp->data;
	
	t1->next=temp->next;
	temp->next->prev=t1;
	free(temp);

	return ret;


}
