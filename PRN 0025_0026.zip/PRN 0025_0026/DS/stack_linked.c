#include<stdio.h>
#include<stdlib.h>

struct node {

	int data;
	struct node* next;
};

void push (struct node **p,int val)

{
	struct node * temp;struct node* t1;
	t1=*p;
	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
	}
	else
	{
		while(t1->next!=NULL)
			t1=t1->next;
		t1->next=temp;
	}

}

void pop(struct node** p)
{	
	struct node *temp=*p,*t1=*p;
	if (*p==NULL)
	{	printf("stack is empty\n");
		return;
	}
	else
	{
		while (temp->next!=NULL){
			t1=temp;
			temp=temp->next;
			}
		t1->next=NULL;
		free(temp);


	}

}

void display(struct node *p)
{ struct node*t1;
	t1=p;
	while(t1!=NULL)
	{
		printf("%d\t",t1->data);
		t1=t1->next;

	}

}

int main()
{
	struct node* head=NULL;
	int ch,val;
	while(1){
	printf("\n\nenter the choice:1-> push\t 2->display\t 3-> delete\t4->exit\n");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("enter the value\n");
		      scanf("%d",&val); 
		       push(&head,val);
		       break;
		case 2:printf("____________________list___________________\n");
		       display(head);
			break;
		case 3: pop(&head);
			break;
		case 4: exit(0);
	}

}

}
