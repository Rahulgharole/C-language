#include<stdio.h>
#include<stdlib.h>


struct node{
	int data;
	struct node* next;

};

void insertatend(struct node **p,int val);
void display(struct node*p);
void insertAtBeg(struct node **p,int val);
void insertAtPos(struct node **p, int val,int pos);
int DelatPos(struct node**p,int pos);
int DeleteEnd(struct node**p);
int main()
{
	struct node* head=NULL;
	int choice,val,pos;
	while(1)
	{
	printf("\nenter the choice\n 1--> insertatend\t2--> display\t 3-->exit \t 4->insertatBeg\t 5->insertAtPos\t 6-->Delete at position \t 7->delete at end\n ");
	scanf("%d",&choice);
	switch(choice)
	{
		case 1: printf("\nenter the data\n");
			scanf("%d",&val);
			insertatend(&head,val);
			break;
		case 3: exit(0);
		case 2: printf("\n________________list______________\n");
			display(head);
			break;

		case 4: printf("Enter the data\n");
			scanf("%d",&val);
			insertAtBeg(&head,val);
			break;
		case 5: printf("Enter the data and possition\n");
			scanf("%d%d",&val,&pos);
			insertAtPos(&head,val,pos);
			break;
		case 6: printf("enter the node position to delete\n");
			scanf("%d",&pos);
			int r=DelatPos(&head,pos);
			printf("deleted data value=%d\n",r);
			break;
		case 7:  r=DeleteEnd(&head);
			printf("deleted data value=%d\n",r);
			break;
		}
	}


}

void insertatend(struct node **p,int val)
{
	struct node *temp;struct node *t1;
	t1=*p;
	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
	}
	else{	
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		t1->next=temp;
	}
	temp->next=*p;

}

void display(struct node *p){
	struct node *a;
	a=p;
	do{
		printf("%d\t",p->data);
		p=p->next;
	}
	while(p!=a);
}


void insertAtBeg(struct node **p,int val)
{
	
	struct node *temp;struct node *t1;
	t1=*p;
	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	while(t1->next!=*p)
		{		t1=t1->next;}
	t1->next=temp;
	temp->next=*p;
	*p=temp;
	
}

void insertAtPos(struct node **p, int val, int pos){

	if(pos==1){
		insertAtBeg(p,val);
		return;

	}
	struct node *temp;
	struct node *t1;
	t1=*p;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=val;
	temp->next=NULL;
	int i=1;
	while(i++ < (pos-1)){
		t1=t1->next;


	}
	temp->next=t1->next;
	t1->next=temp;


}

int DelatPos(struct node**p,int pos)

{
	struct node* t1;struct node* temp;
	t1=*p;
	temp=*p;
	int i=0;
	while(i<(pos-1))
	{
		t1=temp;
		temp=temp->next;
		++i;

	}

	int ret=temp->data;

	t1->next=temp->next;
	free(temp);

	return ret;
}

int DeleteEnd(struct node **p)
{
	struct node *temp;struct node *t1;struct node *a;
	a=*p;
	temp=t1=*p;
	
	while(temp->next!=a)
	{
		t1=temp;
		temp=temp->next;
	}
	t1->next=temp->next;
	int ret=temp->data;
	free(temp);
	return ret;

}

