#include<stdio.h>
#include<stdlib.h>
#define size 5

int  pop (int * arr,int * t);
void push(int*,int*,int);
void display(int*,int);
int main(){

	int ch,data,ret;
	int arr[size];int top=-1;
	while(1)
	{
	printf("enter choice\n");
	printf("1:push\t 2: pop\t 3:exit \t 4: display stack\n");

	scanf("%d",&ch);
	switch(ch){
	
		case 1: printf("enter the element\n");
			scanf("%d",&data);
			push(arr,&top,data);
			break;

		case 3: exit(0);

		case 2: 
                        ret=pop(arr,&top);
			if(ret!=0)
			printf("poped element is \t%d\n\n",ret);
                       break;
		case 4:printf("\n--------stack is-------\n"); 
		       display(arr,top);
			break;

	}

	}

}

void push(int* arr,int *t,int data)
{
	if(*t==(size-1))
	{
		printf("stack is full\n");
		return;
	}
	++*t;
	arr[*t]=data;

}

int  pop (int * arr,int * t)

{
	if(*t==-1){

		printf("there is nothing to pop\n");
		return 0;
	}
	int temp=arr[*t];
	arr[*t]=0;
	--(*t);
	return temp;

}

void display(int *arr,int top)
{
	for (int i=0;i<=top;i++)
		printf("%d\t",arr[i]);
	printf("\n");

}
