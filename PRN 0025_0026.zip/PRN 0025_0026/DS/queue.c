#include<stdio.h>
#include<stdlib.h>
#define size 5

int  delete(int * arr,int * t);
void insert(int*,int*,int*,int);
void display(int*,int);
int main(){

	int ch,data,ret;
	int arr[size];int front= -1;int rear=-1;
	while(1)
	{
	printf("enter choice\n");
	printf("1:insert\t 2:delete\t 3:exit \t 4: display stack\n");

	scanf("%d",&ch);
	switch(ch){
	
		case 1: printf("enter the element\n");
			scanf("%d",&data);
			insert(arr,&rear,&front,data);
			break;

		case 3: exit(0);

		case 2: 
                        ret=delete(arr,&front);
			if(ret!=0)
			printf("delete element is \t%d\n\n",ret);
                       break;
		case 4:printf("\n--------stack is-------\n"); 
		       display(arr,rear);
			break;

	}

	}

}

void insert(int* arr,int *r,int*f,int data)
{
	if(*r==(size-1))
	{
		printf("queue is full\n");
		return;
	}
	++*r;
	arr[*r]=data;
	if(*f==-1)
	*f=*r;
}

int  delete(int * arr,int * f)

{
	if(*f==-1){

		printf("there is nothing to delete\n");
		return 0;
	}
	int temp=arr[*f];
	arr[*f]=0;

	++*f;

	return temp;

}

void display(int *arr,int rear)
{
	for (int i=0;i<=rear;i++)
		printf("%d\t",arr[i]);


}
