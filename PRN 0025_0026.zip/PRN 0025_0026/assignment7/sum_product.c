# include<stdio.h>

int sum_prod(int a,int b,int *s,int *p){

	*s=a+b;
	*p=a*b;


}


int main(){

	int a=10,b=20;
	int s,p;
	sum_prod(a,b,&s,&p);
	printf("sum=%d\nproduct=%d",s,p);

}


