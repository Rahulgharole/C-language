#include<stdio.h>

void test(const int *);
void test2(int*);

int main()
{
	int *p=NULL;
	int const  a=10;
	int const *q=&a;

	test(p);
	 test2(q);

	

}

void test ( const int*x)

{

	printf ("conversion done\n");

}

void test2(int*y)
{
	
	printf("conversion done");
}
