#include<stdio.h>
int main()
{
	register int a=10,b=20;
	 char p;
	register char*ptr=&p;
	p=(char)(a+b);
	printf("addition is :%d\n",p);
	printf("*ptr :%d\n",*ptr);



//	printf("address of register is=\n",&a);

}
