#include<stdio.h>


int* test(int);

int y;

int main(){

	int x=10;
	int *z=test(x);
	printf("%d",*z);
}



int* test(int x)
{
	y=x*x;
	return &y;
}
