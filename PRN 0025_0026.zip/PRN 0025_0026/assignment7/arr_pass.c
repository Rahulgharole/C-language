#include<stdio.h>
int fun (int*,int*, int*, int* );
int twod_array();

int main()
{
	int a[4]={2,3,4,5};
	int b[2][3]={1,2,3,4,5,6};
	int sum1,sum2 ,min1,min2 ,max1,max2;
	fun(a,&sum1,&min1,&max1);
	twod_array(b,&sum2);
	printf("sum1=%d\n min1=%d\n max1=%d\n",sum1,min1,max1);

	printf("\nsum2=%d",sum2);

}

int fun(int*p,int*q,int*r,int*s)
{
	*q=0;
	for(int i=0;i<4;i++)
	{
	  *q=*q+*(p+i);
	
	}

	int max=*p;
	for(int i =1;i<4;i++)
	{

		if(*(p+i)>max)
			max=*(p+i);
	}
	*s=max;
	int min=*p;
	for (int i=1;i<4;i++)
	{
		if(*(p+i)<min)
			min=*(p+i);
	}
	*r=min;
	

}

int twod_array(int *b,int *q){

	
	*q=0;
        for(int i=0;i<6;i++)
        {
          *q=*q+*(b+i);

        }

}







