#include<stdio.h>    
int sq[2];
int add(int *);
int mul(int,int);
int* square(int,int);
int div(int,int);
int main(){
	int a,b,result;
	printf("Enter two nos");
	scanf("%d %d",&a,&b);
	
	result=add(square(a,b))+mul(a,div(a,b));

	printf("result=%d",result);
	


}

int add(int *a){

	int c=a[0]+a[1];
	return c;

}

int mul(int a,int b){
	int d=a*b;
	return d;

}


int div(int a,int b)
{
	int x=a/b;
	return x;
}

int* square(int a,int b){

         sq[0]=a*a;
        sq[1]=b*b;
        return sq;

}



