#include<stdio.h>

void test(int,int,int(*fp)(int ,int));
int  sum (int ,int);

int main()
{
	test(10,20,sum);

}

void test(int x,int y,int(*fp)(int ,int ))

{
	int z= fp(x,y);
	printf("sum is%d\n",z);

}

int sum(int x,int y)
{
	int p=x+y;
	return p;

}

