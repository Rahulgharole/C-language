#include<stdio.h>


int hcf(int, int);

int main()

{
int num1, num2,r,nume,deno;
printf("enter two no");
scanf("%d %d",&num1,&num2);
if(num1>num2)
{
        nume=num1;
        deno=num2;
}
else
{
        nume=num2;
        deno=num1;
}

	r= hcf(nume,deno);
	printf(" \ngcd is =%d\",r);
}




int hcf(int nume, int deno)
{
        static int count=0;
	count++;
	if(deno!=0)
	{
		return hcf(deno,nume%deno );	
			
	}
	else
          {    printf("count of function call is =  %d \n",count);
		return nume;
	   
	  }	
}
