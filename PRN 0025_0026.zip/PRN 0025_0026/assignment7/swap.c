#include<stdio.h>
void pass_by_value(int,int);
void pass_by_ref(int* ,int*);
int main()
{
	int a,b;
	 printf("enter the two nos a and b\n");
	 scanf("%d %d",&a,&b);
	 pass_by_value(a,b);
	 pass_by_ref(&a,&b);
	printf("\na and b=%d\t %d\n",a,b);
}

void pass_by_value(int a,int b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;

	printf("\na and b are:%d %d\n",a,b);
	

}


void pass_by_ref(int *p ,int *q)
{
	int temp;
        temp=*p;
	*p=*q;
 	*q=temp;	

}

