#include<stdio.h>



int arr[2];
int* sqr(int a,int b){

	a=a*a;
	b=b*b;
	arr[0]=a;
	arr[1]=b;
	return &arr;

}



int main(){

	
	int *ptr=(int *)sqr(10,20);
	printf("%d %d",*(ptr+0),*(ptr+1));



}


