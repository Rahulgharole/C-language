#include<stdio.h>

int main(){

	int a=10;
	int *i_p=&a;

	void *v_p=&a;
	
	char *c_p;
	c_p = (char *)v_p;
	printf("*i_p=%d\n *c_p=%d",*i_p,*c_p);
	



}


