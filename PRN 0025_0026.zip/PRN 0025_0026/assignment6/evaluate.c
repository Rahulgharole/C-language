#include<stdio.h>
int main()
{

	int a1;
	int a[5] = {10, 20, 30, 40, 50 };
	int *p=a, *q=*(&a+1)-1;
	
	
	printf("*q=%d\n",*q);
	
	printf("*p++=%d\n",*p++);

	printf("*++p=%d\n",*++p);
	printf("(*p)++=%d\n",(*p)++);
	printf("++(*p)=%d\n",++(*p));
	printf("++*p=%d\n",++*p);
	printf("*(p++)=%d\n",*(p++));
	printf("*(++p)=%d\n",*(++p));
	printf("*q--=%d\n",*q--);
	printf("*--q=%d\n",*--q );
	printf("--(*q)=%d\n",--(*q) );
	printf("--*q=%d\n",--*q );
	printf("(*q)--=%d\n",(*q)-- );
	printf("*(q--)%d\n",*(q--) );
	
	printf("*(--q)%d\n", *(--q));
}
