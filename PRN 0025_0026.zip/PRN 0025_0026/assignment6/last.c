#include<stdio.h>
int main()
{
	int a[]={1,2,3,4,5,6};

	int *p=(int *)(&a+1);
	printf("Last element=%d",*(p-1));


}
