#include<stdio.h>

int main(){
       short int a=0x1122;
        char *p=(char *)&a;
        char x[2];
        printf("Little endian: ");
        for(int i=0;i<=1;i++){

                x[i]=*(p+i);
                printf("%x",x[i]);


        }

        printf("\nBig endian: ");
        char (*ptr)[2];
        ptr=&x+1;
        for(int i=1;i<=2;i++){
        printf("%x",*(*ptr-i));


        }


}

