#include<stdio.h>
int main()

{
	int(*p)[3][4];
	
	printf("%ld %ld %ld %ld", sizeof(p),sizeof(*p),sizeof(**p),sizeof(***p));

}
