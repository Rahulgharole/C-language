#include<stdio.h>
#include<assert.h>

int main()
{
	int i=10;
	int *p=NULL;

//	p=&i;

	//if(p!=NULL)
	assert(p==NULL);
	printf("%d\n",*p);

	

	return 0;
}
