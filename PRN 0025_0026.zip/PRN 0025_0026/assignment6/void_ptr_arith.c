#include<stdio.h>

int main(){
	
	int a=10;
	
	void *v_p=&a;
	
	int value = *((int *) v_p)+2; 
	
	
	
	printf("v_p=%p\n",v_p);
	
	++v_p;


	
	//printf("*v_p=%d\n",*((int *) v_p));
	
	printf("a=%d\n;",a);


	printf("value=%d\n",value);

	printf("v_p=%p",v_p);








	


}


