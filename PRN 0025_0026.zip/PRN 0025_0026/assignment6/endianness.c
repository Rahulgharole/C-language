#include<stdio.h>


int main(){

	int a=0x11223344;
	char *c;
	c=(char *)&a;
	printf("c=%x\n",*c);
	if(*c==0x44)
		printf("Little endian\n");
	else if(*c==0x11) 
		printf("Big endiani\n");


}
