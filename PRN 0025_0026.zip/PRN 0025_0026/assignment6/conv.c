#include<stdio.h>

int main(){
	int a=0x11223344;
	char *p=(char *)&a;
	char x[4];
	printf("Little endian: ");
	for(int i=0;i<=3;i++){
	
		x[i]=*(p+i);
		printf("%x",x[i]);
	
	
	}

	printf("\nBig endian: ");
	//char (*ptr)[4];
//	ptr=&x+1;
	
	char *ptr;
	ptr=(char*)(&x+1);
	
	
	for(int i=1;i<=4;i++){
	printf("%x",*(ptr-i));


	}


}


