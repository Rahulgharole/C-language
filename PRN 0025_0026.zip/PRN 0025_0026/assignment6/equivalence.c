#include<stdio.h>
int main()
{
	int arr[3][4]={1,2,3,4,5,6,7,8,9,10,11,12};
	int (*p)[4];
	
//	int (*p)[3][4];
	p=arr;

//	p=&arr;
	printf("sizeof(p)=%u \nsizeof(*p)= %u \nsizeof(**p)= %u \n p=%u\n p+1=%u\n &arr=%u" ,sizeof(p),sizeof(*p),sizeof(**p),p,p+1,&arr);
	
	for(int i=0;i<=2;i++){
		for(int j=0;j<=3;j++){
		


			// all are working same
			printf("\n%d ",arr[i][j]);
			printf("\n%d ",(*(p+i))[j]);//[j] is as index of p
			printf("\n%d ",*(*(p+i)+j));
		
		
		
		}
	
	
	
	}


}

