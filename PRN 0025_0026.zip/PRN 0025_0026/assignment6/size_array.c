#include<stdio.h>

int main(){

	int arr[5]={1,2,3,4,5}; 
	int (*parr)[5];
	parr=&arr;
	printf("sizeof(parr)=%lu\n sizeof(*parr)=%lu\n sizeof(**parr)=%lu\n",sizeof(parr) ,sizeof(*parr), sizeof(**parr));
	printf("*(*parr)=%d  *(*(parr+1)-1)=%d",*(*parr),*(*(parr+1)-1));


}




