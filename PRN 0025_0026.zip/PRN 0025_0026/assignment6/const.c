#include<stdio.h>

int main(){

	int const x=45;
	int y=9;

	//const int *p=&x;
	


	//int const * p
	//int * const p =&x;
	const int * const p = &x;
	
	//*p=20;
	//printf("*p=%d",*p);
	
	
	//printf("&X=%u",p);
	//printf("++&x=%u",++p);
       
	printf("(*p)++=%d",(*p)++);

	//p=&y;


}
