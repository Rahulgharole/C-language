#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>

int mylen(char *c){
	int i=0, j=0;
	while(c[j]!='\0'){
	i++;
	j++;
	}
	return i;
}

void mycopy(char *c){
	int l=mylen(c);
	char str1[l]; int j=0;
	while(c[j]!='\0'){
	
		str1[j]=c[j];
		j++;	
	}	
	printf("copy of str=%s\n",str1);
}

void myconcatenation(char *c, char *c1,int i, int j){
	char str[i+j];
	int l=0;
	for(int k=0;k<i;k++){
		str[l]=c[k];
		l++;
	}
	for (int u=0;u<j;u++){
	
		str[l]=c1[u];
		l++;
	}
	printf("concatenated string=%s\n",str);


}

void compare(char *c, char *c1,int l, int m){
		if(l!=m){
		printf("Not equal");
		}
		else{

			int flag=0;
			int flag1=0;
			for(int i=0;i<l;i++)
				{
				if(c[i]==c1[i]){
				flag=1;
				}
			else flag1=1;
		}
		
		if(flag==1 && flag1==0)
		printf("strings are equal\n\n\n");
		else 
		printf("strings are not equal\n\n\n");
	}
}

void reverse (char * str,int l)
{	char star1[10];

	for(int i=(l-1), j=0;i>=0||j<l;i--,j++)
	{
		star1[j]=str[i];
	}
		printf("%s\n\n",star1);
}

void occurance(char* str,int l)
{	char ch,i,flag=0;
	printf("enter the character whose occurance do you want to find\n");
	
	__fpurge(stdin);
	scanf("%c",&ch);
	for( i=0;i<l;i++)
	{
	 	if(str[i]==ch)
		{
			flag=1;
			break;
		}	
	}
 	if(flag==1)
		printf("occurance of character %c is at position %d\n",ch,i+1);
	else
		printf("character not found\n");

}



int main()
{
	int ch, l;
	char str[10];
	char str1[10];
	while(1){switch(ch){
	
		case 1:
			 l=mylen(str);
			printf("Length=%d\n",l);
			break;
		case 2: exit(0);

		case 3:	
			mycopy(str);
			break;
		case 4:
			printf("enter another string\n");
			scanf("%s",str1);
			int i=mylen(str);
			int j=mylen(str1);
			myconcatenation(str,str1,i,j);
			break;
   	printf("enter the operation choice\n1->Finding length\n2->exit\n3->copy\n4->concatenate\n5->compare\n6-->reverse in memory\n7-> occurance of character");
   	scanf("%d",&ch);
 	if(ch!=2){	
	printf("enter the string\n");
	scanf("%s",str);}

	switch(ch){
	
		case 1:
			 l=mylen(str);
			printf("Length=%d\n",l);
			break;
		case 2: exit(0);

		case 3:	
			mycopy(str);
			break;
		case 4:
			printf("enter another string\n");
			scanf("%s",str1);
			int i=mylen(str);
			int j=mylen(str1);
			myconcatenation(str,str1,i,j);
			break;

		case 5:
			printf("enter another strings\n");
			scanf("%s",str1);
			int n=mylen(str);
			int m=mylen(str1);
			compare(str,str1,n,m);
			break;
		case 6:	
	       		l =mylen(str);
			reverse(str,l);
			break;

		case 7: l=mylen(str);
			occurance(str,l);
			break;
	
	}
	}
	



}
