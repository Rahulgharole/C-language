#include<stdio.h>


int main(int argc, int *argv[])
{
	printf("%s\n%s\n",argv[1],argv[2]);
}
