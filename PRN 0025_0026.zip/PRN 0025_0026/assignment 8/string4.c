

#include<stdio.h>
#include<string.h>

int main()
{
	int str1[100];
	strcpy(str1,"9882");
	printf("Conveot String to integer %ld",atoi(str1));
	return 0;
}

