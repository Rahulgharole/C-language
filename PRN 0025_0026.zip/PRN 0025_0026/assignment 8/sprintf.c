#include<stdio.h>
#include<stdlib.h>

int mylen(char *c){
	int i=0, j=0;
	while(c[j]!='\0'){
	i++;
	j++;
	}
	return i;
}

void mycopy(char *c){
	int l=mylen(c);char string[100];
	char str1[l]; int j=0;
	while(c[j]!='\0'){

		str1[j]=c[j];
		j++;
	}
	sprintf(string,"copy of str=%s\n",str1);
	puts(string);
}

void myconcatenation(char *c, char *c1,int i, int j){
	char str[i+j];char string[100];
	int l=0;
	for(int k=0;k<i;k++){
		str[l]=c[k];
		l++;
	}
	for (int u=0;u<j;u++){

		str[l]=c1[u];
		l++;
	}
	sprintf(string,"concatenated string=%s\n",str);
	puts(string);

}

int main()
{
	int ch ,l;char string[100];char str[10];char str1[10];
	while(1){
	printf("enter the choice\n 1--> find length\t2--> exit\t3-->copy\t4-->concatenation\n");
	scanf("%d",&ch);if(ch!=2){
	printf("enter the string\n");
	scanf("%s",str);}

	switch(ch){
	
		case 1:
			 l=mylen(str);
			sprintf(string,"Length=%d\n",l);
			puts(string);
			break;
		case 2: exit(0);

		case 3:	
			mycopy(str);
			break;
		case 4:
			printf("enter another string\n");
			scanf("%s",str1);
			int i=mylen(str);
			int j=mylen(str1);
			myconcatenation(str,str1,i,j);
			break;
	}
	}
}
