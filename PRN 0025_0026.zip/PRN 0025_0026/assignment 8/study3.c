

1> strncpy




2> strncat, 
	

	
3>strncmp,
       



4>strcasecmp,
       


5>strncasecmp,
	
	
	
	
6>strchr,
	
	
	
7>strrchr,
	
	
	
8>strstr,

	
9>strtok, 
	
10>sprintf, 
	
11>snprintf, 
	
12>sscanf
