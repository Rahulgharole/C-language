#include<stdio.h>
int main()
{
int a=4,b=5,c=6;
int greater;
 greater= (a>b?(a>c?a:c):(b>c?b:c));
 printf("%d\n",greater);

}
