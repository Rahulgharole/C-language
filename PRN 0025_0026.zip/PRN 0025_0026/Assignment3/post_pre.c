#include<stdio.h>

int main()

{

	int k,i,y,x,q,p;
	i=1, x=1,p=9;
	k=++i;	// 2

	printf("%d\n",k);
	k=i++;    // 2
	
	printf("%d\n",k);
	y=x++*10;  // 10
	
	printf("%d\n",y);
	y=++x*10;  // 30
	
	printf("%d\n",y);
	q=p--/3;   //3
	
	printf("%d\n",q);
	q=--p/3; //2

	printf("%d\n",q);
}
