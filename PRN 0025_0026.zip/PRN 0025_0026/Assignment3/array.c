#include<stdio.h>


int main(){
	int bigger,smaller;
	float s=0;
	float avg;
	int arr[3]={1,2,3};
	for(int i=0;i<3;i++)
	s=s+arr[i];
	avg=s/3;
	printf("sum=%f \navg=%f\n",s,avg);
	

	bigger= arr[0]>arr[1]?(arr[0]>arr[2]?arr[0]:arr[2]):(arr[1]>arr[2]?arr[1]:arr[2]);
        smaller= arr[0]<arr[1]?(arr[0]<arr[2]?arr[0]:arr[2]):(arr[1]<arr[2]?arr[1]:arr[2]);
	printf("bigger no is %d \n smaller no is %d \n",bigger,smaller);

}




