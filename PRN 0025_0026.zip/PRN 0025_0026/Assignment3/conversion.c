#include<stdio.h>
#include<math.h>
int main ()
{
	int dec=10,r,bin=0,i=1;
	while(dec!=0)
	{
		r=dec%2;
		dec=dec/2;
		bin=bin+i*r;
		i=i*10;
	}

  	printf("binary no is  %d \n",bin);

	int b1=1010,r1, j=1,d1=0;
	while(b1!=0)
	{
		r1=(b1%10);
		d1=d1+r1*j;
		j=j*2;
		b1=b1/10;

	}
	printf("dec no is  %d\n",d1);
return 0;
}
