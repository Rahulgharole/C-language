#include<stdio.h>

int main()

{
	int num,c=1;
	printf("Enter the limit");
	scanf("%d",&num);

	for (int i=0;i<=num;i++)
	{
		
		for(int j=num-1;j>=i;j--)
			printf(" ");

		for(int k=0;k<=i;k++)
		{
			if(i==0 || k==0)
				c=1;
			else
			c=c*(i-k+1)/k;
			

			printf(" %d",c);	
		}

		printf("\n");

	}


}
