#include<stdio.h>

int main ()
{
  int a ,b,c,d,to_sec,hr,min,sec,total_sec=0;

  printf("enter  1 for time to sec format\n 2 for sec to time format");
  scanf("%d",&a);

  switch(a)
  {
	case 1: printf("enter hours , minuits, sec");
		scanf("%d %d %d",&b,&c, &d);
		total_sec= 60*60*b+60*c+d;
		printf("Total sec=%d",total_sec);
		break;
	case 2:
		printf("Enter total sec");
		scanf("%d",&to_sec);
		hr=to_sec/3600;
		min=(to_sec-hr*3600)/60;
		sec=(to_sec-hr*3600)-min*60;
		printf("hr:min:sec=%d:%d;%d",hr,min,sec);
		break;


  }

}
