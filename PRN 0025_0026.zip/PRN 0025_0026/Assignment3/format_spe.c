#include<stdio.h>

int main(){

	int a=10;
	float b=20.4545;
	float c=4.5555555;
	printf("%5d %05d %-5d %20.2f %2f",a,a,a,c,b);

}
