#include<stdio.h>

int main(){

	int z,d,a=10,b=20,c=30;
	d=++a,++b,++c,a+5;
	z=(++a,++b,++c,a+5);
	printf("d=%d z=%d",d,z);

}
